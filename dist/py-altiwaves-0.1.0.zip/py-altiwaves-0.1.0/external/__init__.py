# outer __init__.py
import wavelet
