# outer __init__.py
'''
altimetry.externals module
@summary: Contains code from the outer world
@author: Renaud DUSSURGET, LER/PAC IFREMER.
@change: Create in December 2012 by RD.
'''