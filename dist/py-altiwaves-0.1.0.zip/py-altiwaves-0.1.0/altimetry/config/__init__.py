# outer __init__.py
'''
config module
@summary: Set up configuration of altimetry tools
@author: Renaud DUSSURGET, LER/PAC IFREMER.
@change: Create in November 2012 by RD.
'''
from defaults import defaults